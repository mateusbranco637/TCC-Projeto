const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const pool = require('../db/pool');

const router = express.Router();
const SALT_ROUNDS = 12;

function gerarToken(usuario, papel) {
    return jwt.sign({ sub: usuario.id, papel }, process.env.JWT_SECRET, {
        expiresIn: process.env.JWT_EXPIRES_IN || '8h',
    });
}

function tratarErroValidacao(req, res) {
    const erros = validationResult(req);
    if (!erros.isEmpty()) {
        res.status(400).json({ erro: 'Dados inválidos.', detalhes: erros.array() });
        return true;
    }
    return false;
}

// Converte "000.000.000-00" -> "00000000000" (só dígitos), como a coluna CHAR(11) espera
function apenasDigitos(valor) {
    return String(valor || '').replace(/\D/g, '');
}

// =========================================================
// POST /api/auth/registro/paciente
// =========================================================
router.post(
    '/registro/paciente',
    [
        body('nome').trim().notEmpty().withMessage('Nome é obrigatório.'),
        body('data_nascimento').isISO8601().withMessage('Data de nascimento inválida (use AAAA-MM-DD).'),
        body('cpf').customSanitizer(apenasDigitos).isLength({ min: 11, max: 11 }).withMessage('CPF deve ter 11 dígitos.'),
        body('email').isEmail().normalizeEmail().withMessage('Email inválido.'),
        body('telefone').trim().notEmpty().withMessage('Telefone é obrigatório.'),
        body('senha').isLength({ min: 6 }).withMessage('Senha deve ter ao menos 6 caracteres.'),
    ],
    async (req, res) => {
        if (tratarErroValidacao(req, res)) return;

        const { nome, data_nascimento, cpf, email, telefone, senha } = req.body;

        try {
            const senha_hash = await bcrypt.hash(senha, SALT_ROUNDS);
            const resultado = await pool.query(
                `INSERT INTO pacientes (nome, data_nascimento, cpf, email, telefone, senha_hash)
                 VALUES ($1, $2, $3, $4, $5, $6)
                 RETURNING id, nome, email, telefone, criado_em`,
                [nome, data_nascimento, cpf, email, telefone, senha_hash]
            );

            const paciente = resultado.rows[0];
            const token = gerarToken(paciente, 'paciente');
            return res.status(201).json({ usuario: { ...paciente, papel: 'paciente' }, token });
        } catch (err) {
            if (err.code === '23505') {
                return res.status(409).json({ erro: 'Já existe um paciente com este CPF ou email.' });
            }
            // eslint-disable-next-line no-console
            console.error(err);
            return res.status(500).json({ erro: 'Erro ao registrar paciente.' });
        }
    }
);

// =========================================================
// POST /api/auth/registro/psicologo
// =========================================================
router.post(
    '/registro/psicologo',
    [
        body('nome').trim().notEmpty().withMessage('Nome é obrigatório.'),
        body('data_nascimento').isISO8601().withMessage('Data de nascimento inválida (use AAAA-MM-DD).'),
        body('cpf_cnpj').customSanitizer(apenasDigitos).isLength({ min: 11, max: 14 }).withMessage('CPF/CNPJ inválido.'),
        body('numero_crp').trim().notEmpty().withMessage('Número do CRP é obrigatório.'),
        body('telefone').trim().notEmpty().withMessage('Telefone é obrigatório.'),
        body('email').isEmail().normalizeEmail().withMessage('Email inválido.'),
        body('senha').isLength({ min: 6 }).withMessage('Senha deve ter ao menos 6 caracteres.'),
        body('especialidade').optional({ nullable: true, checkFalsy: true }).trim(),
        body('bio').optional({ nullable: true, checkFalsy: true }).trim(),
    ],
    async (req, res) => {
        if (tratarErroValidacao(req, res)) return;

        const { nome, data_nascimento, cpf_cnpj, numero_crp, telefone, email, senha, especialidade, bio } = req.body;

        try {
            const senha_hash = await bcrypt.hash(senha, SALT_ROUNDS);
            const resultado = await pool.query(
                `INSERT INTO psicologos
                    (nome, data_nascimento, cpf_cnpj, numero_crp, telefone, email, senha_hash, especialidade, bio)
                 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                 RETURNING id, nome, email, telefone, especialidade, bio, criado_em`,
                [nome, data_nascimento, cpf_cnpj, numero_crp, telefone, email, senha_hash, especialidade || null, bio || null]
            );

            const psicologo = resultado.rows[0];
            const token = gerarToken(psicologo, 'psicologo');
            return res.status(201).json({ usuario: { ...psicologo, papel: 'psicologo' }, token });
        } catch (err) {
            if (err.code === '23505') {
                return res.status(409).json({ erro: 'Já existe um psicólogo com este CPF/CNPJ, CRP ou email.' });
            }
            // eslint-disable-next-line no-console
            console.error(err);
            return res.status(500).json({ erro: 'Erro ao registrar psicólogo.' });
        }
    }
);

// =========================================================
// POST /api/auth/login
// body: { email, senha, papel: 'paciente' | 'psicologo' }
// =========================================================
router.post(
    '/login',
    [
        body('email').isEmail().normalizeEmail().withMessage('Email inválido.'),
        body('senha').notEmpty().withMessage('Senha é obrigatória.'),
        body('papel').isIn(['paciente', 'psicologo']).withMessage("papel deve ser 'paciente' ou 'psicologo'."),
    ],
    async (req, res) => {
        if (tratarErroValidacao(req, res)) return;

        const { email, senha, papel } = req.body;
        const tabela = papel === 'paciente' ? 'pacientes' : 'psicologos';

        try {
            const resultado = await pool.query(
                `SELECT * FROM ${tabela} WHERE email = $1`,
                [email]
            );

            const usuario = resultado.rows[0];
            if (!usuario) {
                return res.status(401).json({ erro: 'Email ou senha incorretos.' });
            }

            const senhaValida = await bcrypt.compare(senha, usuario.senha_hash);
            if (!senhaValida) {
                return res.status(401).json({ erro: 'Email ou senha incorretos.' });
            }

            delete usuario.senha_hash;
            const token = gerarToken(usuario, papel);
            return res.json({ usuario: { ...usuario, papel }, token });
        } catch (err) {
            // eslint-disable-next-line no-console
            console.error(err);
            return res.status(500).json({ erro: 'Erro ao fazer login.' });
        }
    }
);

module.exports = router;
